﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;

namespace ProjektoG
{
    /// <summary>
    /// Logika interakcji dla klasy Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();

        }
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-0AKHNCB\SQLEXPRESS;Initial Catalog=ShoeShop;Integrated Security=True");
        private void Powrot3(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();

        }
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox box = sender as TextBox;
            box.Text = string.Empty;
            box.Foreground = Brushes.Black;
            box.GotFocus -= TextBox_GotFocus;
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox box = sender as TextBox;
            if (box.Text.Trim().Equals(string.Empty))
            {
                box.Text = "...";
                box.Foreground = Brushes.LightGray;
                box.GotFocus += TextBox_GotFocus;
            }
        }
        private void btnadd_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                string query = "INSERT INTO StanMagazynu VALUES("
                    + "'" + this.txtNazwa.Text + "',"
                    + "'" + this.txtMarka.Text + "',"
                    + "'" + this.txtRozmiar.Text + "',"
                    + "'" + this.txtStan.Text + "',"
                    + "'" + this.txtCena.Text + "')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Successfully added!");
                Refresh();

            }
            catch (Exception)
            {
                MessageBox.Show("Make sure values are correct!");
            }
            finally
            {
                connection.Close();
            }
             void Refresh()
            {
                Window1 refresh = new Window1();
                Application.Current.MainWindow = refresh;
                refresh.Show();
                this.Close();
            }
        }
    }
}
