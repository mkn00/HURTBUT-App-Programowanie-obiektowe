﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;

namespace ProjektoG
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-0AKHNCB\SQLEXPRESS;Initial Catalog=ShoeShop;Integrated Security=True");
        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                // Przypięcie działania query z SQL do aplikacji
                string loginQuery = "SELECT (1) FROM Login WHERE Login = @Login AND Haslo = @Haslo";
                SqlCommand command = new SqlCommand(loginQuery, connection);


                // Wartość skalarna
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("@Login", txtlogin.Text);
                command.Parameters.AddWithValue("@Haslo", passbox.Password);

                int count = Convert.ToInt32(command.ExecuteScalar());


                if (count == 1)
                {
                    Window1 window1 = new Window1();
                    window1.Show();


                    this.Close();
                }
                else
                {
                    MessageBox.Show("Wprowadź poprawny login lub hasło!");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {

                connection.Close();
            }
        }
    }
}