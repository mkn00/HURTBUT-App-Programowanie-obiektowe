﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;

namespace ProjektoG
{
    /// <summary>
    /// Logika interakcji dla klasy Window6.xaml
    /// </summary>
    public partial class Window6 : Window
    {
        public Window6()
        {
            InitializeComponent();
            FillComboBox();
        }
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-0AKHNCB\SQLEXPRESS;Initial Catalog=ShoeShop;Integrated Security=True");
        private void Btnrmv_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                string query = "DELETE FROM StanMagazynu WHERE ID=" + this.comboid.Text;
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Successfully removed");
                Refresh();
            }
            catch (Exception)
            {
                MessageBox.Show("Nie znaleziono");
            }
            finally
            {
                connection.Close();
            }
        }
        private void Refresh()
        {
            Window1 refresh = new Window1();
            Application.Current.MainWindow = refresh;
            refresh.Show();
            this.Close();
        }
        private void Powrot6(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();

        }
        public void FillComboBox()
        {
            // here we are going to fill combobox with data
            // in our case it is ID of order


            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                string query = "SELECT ID FROM StanMagazynu";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);

                // assign datasource to the combobox using datatable
                comboid.ItemsSource = table.DefaultView;
                comboid.DisplayMemberPath = "ID";

            }
            catch (Exception)
            {
                MessageBox.Show("Something went wrong :(");
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
