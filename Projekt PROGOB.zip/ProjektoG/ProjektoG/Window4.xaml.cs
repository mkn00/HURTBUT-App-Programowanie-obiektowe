﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Data.Entity;

namespace ProjektoG
{
    /// <summary>
    /// Logika interakcji dla klasy Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        public Window4()
        {
            InitializeComponent();

        }
        private void Powrot4(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();

        }
        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-0AKHNCB\SQLEXPRESS;Initial Catalog=ShoeShop;Integrated Security=True");
        private void Pracownicy(object sender, RoutedEventArgs e)
        {
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }

                // runs a query on connected database
                string loginQuery = "SELECT (1) FROM AdminLog WHERE HasloA = @HasloA";
                SqlCommand command = new SqlCommand(loginQuery, connection);


                // declaring scalar variables
                command.CommandType = CommandType.Text;
                command.Parameters.AddWithValue("HasloA", passbox.Password);

                int count = Convert.ToInt32(command.ExecuteScalar());

                // if the returned value equals 1 it means it matches the databsae record
                // --> then move to the next window
                if (count == 1)
                {
                    Pracownicy pracownicy = new Pracownicy();
                    pracownicy.Show();

                    // closing login screen
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Wprowadź poprawne hasło!");
                }
            }
            catch (Exception ex)
            {
                //TODO: Messagebox icon
                MessageBox.Show(ex.Message);
            }
            finally
            {
                // closes the app
                connection.Close();
            }
        }
    }
}